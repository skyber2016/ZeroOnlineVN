﻿using System;

namespace API.Cores.Exceptions
{
    public class UnAuthorizeException : Exception
    {
    }
}
