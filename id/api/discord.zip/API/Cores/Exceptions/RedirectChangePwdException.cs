﻿using System;

namespace API.Cores.Exceptions
{
    public class RedirectChangePwdException : Exception
    {
    }
}
