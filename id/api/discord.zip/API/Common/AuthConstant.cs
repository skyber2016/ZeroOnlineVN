﻿namespace API.Common
{
    public static class AuthConstant
    {
        public const string ADMIN = "631999";
        public const string NON_ADMIN = "0";
    }
}
