﻿namespace API.Common
{
    public static class ChannelConstant
    {
        public const ulong REGISTER = 820663797076328448;
        public const ulong REPORT = 818668444106096650;
        public const ulong GIFT_CODE = 818668444106096650;
        public const ulong DOI_TIEN = 858716300062359552;
        public const ulong WHEEL = 859344699215446026;
        public const ulong WEB_SHOP = 861186952099266610;

    }
}
