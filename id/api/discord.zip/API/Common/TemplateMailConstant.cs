﻿namespace API.Common
{
    public static class TemplateMailConstant
    {
        public static readonly string ResetPassword = @"ResetPassword.html";
        public static readonly string CreateUser = @"CreateUser.html";
        public static readonly string ForgotPassword = @"ForgotPassword.html";
    }
}
