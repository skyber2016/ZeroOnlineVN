﻿namespace API.Common
{
    public enum ConfigCode
    {
        HOOKING_CREATE_USER,
        CREATE_USER_MAIL_TITLE,
        DEFAULT_ROLE
    }
}
