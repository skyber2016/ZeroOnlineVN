﻿namespace API.Common
{
    public static class Boolean
    {
        public static readonly char TRUE = '1';
        public static readonly char FALSE = '0';
    }
}
