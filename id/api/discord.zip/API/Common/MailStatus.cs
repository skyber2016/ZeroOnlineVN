﻿namespace API.Common
{
    public enum MailStatus
    {
        Pendding = 0,
        Complete
    }
}
