﻿namespace API.Common
{
    public static class GiftCodeTypeConstant
    {
        public const int SINGLE = 1;
        public const int MULTIPLE = 2;
    }
}
