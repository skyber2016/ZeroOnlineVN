﻿namespace API.Common
{
    public static class MailTitleConstants
    {
        public static readonly string RESET_PASSWORD = "Cambopay QR Management Password Reset";
        public static readonly string FORGOT_PASSWORD = "Cambopay QR Management Forgot Password";
        public static readonly string CREATE_USER = "Welcome to Cambopay QR Management";
    }
}
