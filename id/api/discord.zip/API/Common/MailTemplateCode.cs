﻿namespace API.Common
{
    public enum MailTemplateCode
    {
        CreateUser
    }
}
