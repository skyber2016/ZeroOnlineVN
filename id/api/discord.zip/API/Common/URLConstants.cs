﻿namespace API.Common
{
    public static class URLConstants
    {
        /// <summary>
        /// METHOD CODE
        /// </summary>
        public const string ResetPassworldLink = "localhost:4200/auth/change-password/";
    }
}
