﻿namespace API.Middlewares
{
    public class CryptoSettings
    {
        public string PrivateKey { get; set; }
        public string PublicKeyDefault { get; set; }
    }
}
