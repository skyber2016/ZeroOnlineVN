﻿namespace API.DTO.RewardShopItem.Responses
{
    public class RewardShopItemCreateRequest
    {
        public int ActionId { get; set; }

        public string Name { get; set; }

        public string Image { get; set; }

        public int Group { get; set; }
    }
}
