﻿namespace API.DTO.Error.Responses
{
    public class ErrorResponse
    {
    }
}
