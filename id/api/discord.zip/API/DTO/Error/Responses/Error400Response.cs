﻿namespace API.DTO.Error.Responses
{
    public class Error400Response
    {
        public string Message { get; set; }
    }
}
