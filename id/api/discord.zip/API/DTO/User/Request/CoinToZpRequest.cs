﻿namespace API.DTO.User.Request
{
    public class CoinToZpRequest
    {
        public int? Money { get; set; }
    }
}
