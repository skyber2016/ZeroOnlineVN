﻿using System.Text.Json.Serialization;

namespace API.DTO.Base
{
    public class StatusResponse
    {
        
    }
}
