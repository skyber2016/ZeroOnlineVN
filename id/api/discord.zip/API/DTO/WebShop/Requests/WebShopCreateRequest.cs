﻿namespace API.DTO.WebShop.Requests
{
    public class WebShopCreateRequest
    {
        public int ItemId { get; set; }
    }
}
