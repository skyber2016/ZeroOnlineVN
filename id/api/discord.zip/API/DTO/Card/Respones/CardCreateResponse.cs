﻿namespace API.DTO.Card.Respones
{
    public class CardCreateResponse
    {
        public string Message { get; set; }
    }
}
