﻿namespace API.DTO.Authenticate.Responses
{
    public class RegisterResponse
    {
        public int Id { get; set; }
    }
}
