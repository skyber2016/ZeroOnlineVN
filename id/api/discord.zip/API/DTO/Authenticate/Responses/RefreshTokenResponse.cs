﻿namespace API.DTO.Authenticate.Responses
{
    public class RefreshTokenResponse
    {
        public string Token { get; set; }
    }
}
