﻿namespace API.DTO.GiftCode.Requests
{
    public class GiftCodeReceiveRequest
    {
        public string GiftCode { get; set; }
    }
}
