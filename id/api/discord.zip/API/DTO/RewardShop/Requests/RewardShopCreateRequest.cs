﻿namespace API.DTO.RewardShop.Requests
{
    public class RewardShopCreateRequest
    {
        public int Group { get; set; }
    }
}
