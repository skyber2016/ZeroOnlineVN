﻿using System;

namespace API.DTO.Wheel.Responses
{
    public class WheelLogResponse
    {
        public string CharName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Desc { get; set; }
    }
}
