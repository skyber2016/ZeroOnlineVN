﻿using System;

namespace API.Attributes
{
    public class IgnoreRoleAttribute : Attribute
    {
    }
}
