﻿using System;

namespace API.Attributes
{
    public class AdminAttribute : Attribute
    {
    }
}
