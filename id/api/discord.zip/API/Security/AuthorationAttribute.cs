﻿using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace API.Security
{
    public class AuthorationAttribute : JwtBearerEvents
    {
    }

}
