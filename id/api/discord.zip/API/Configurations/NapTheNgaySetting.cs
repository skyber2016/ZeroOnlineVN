namespace API.Configurations
{
    public class NapTheNgaySetting
    {
        public string Email { get; set; }
        public int MerchantId { get; set; }
        public string Secretkey { get; set; }
    }
}
