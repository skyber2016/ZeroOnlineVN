﻿namespace API.Configurations
{
    public class ConnectionSetting
    {
        public string DefaultConnection { get; set; }
    }
}
