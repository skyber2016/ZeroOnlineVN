namespace API.Configurations
{
    public class AppSettings
    {
        public int EventType_Statistic { get; set; }
        public int VIPDefault { get; set; }
        public string[] Admin { get; set; }
    }
}
