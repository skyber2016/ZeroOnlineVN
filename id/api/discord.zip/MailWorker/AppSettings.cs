﻿namespace MailWorker
{
    public class AppSettings
    {
        public string Email { get; set; }
        public string Secret { get; set; }
    }
}
