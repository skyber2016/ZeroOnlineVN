﻿namespace API.Common
{
    public static class BotCommand
    {
        public static readonly string CongTien = "/congtien";
        public static readonly string GiftCode = "/code";
    }
}
