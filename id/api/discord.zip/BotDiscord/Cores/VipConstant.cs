﻿namespace API.Common
{
    public static class VipConstant
    {
        public static int VIP_1 = 500000;
        public static int VIP_2 = 1000000;
        public static int VIP_3 = 2000000;
        public static int VIP_4 = 6000000;
        public static int VIP_5 = 8000000;
        public static int VIP_6 = 12000000;
    }
}
