﻿namespace BotDiscord
{
    public static class ChannelConstant
    {
        public const ulong REGISTER = 820663797076328448;
        public const ulong REPORT = 818668444106096650;
        public const ulong LOGIN_VPS = 858945711563735040;
    }
}
