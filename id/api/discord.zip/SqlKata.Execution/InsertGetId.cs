namespace SqlKata.Execution
{
    public class InsertGetIdRow<T>
    {
        public T Id { get; set; }
    }
}