﻿using API.Helpers;
using AutoAnswer.Services;
using AutoAnswer.Services.Interfaces;
using System;
using System.Data;
using System.Threading.Tasks;

namespace API.Cores
{
    public interface IUnitOfWork
    { 
        ILoggerManager Logger { get; set; }
        IAnswerService AnswerService { get; set; }
        AtomService AtomService { get; set; }
    }
    public class UnitOfWork : IUnitOfWork
    {
        public ILoggerManager Logger { get; set; }
        public IAnswerService AnswerService { get; set; }
        public AtomService AtomService { get; set; }


        public UnitOfWork()
        {
            this.AnswerService = new AnswerService();
            this.Logger = new LoggerHelper();
        }

    }
}
