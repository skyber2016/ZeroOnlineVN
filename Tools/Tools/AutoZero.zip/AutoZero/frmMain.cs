﻿using AutoAnswer.Services;
using SimpleTCP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoZero
{
    public partial class frmMain : Form
    {
        private MiddlewareService MiddlewareService { get; set; }
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            try
            {
                if (this.MiddlewareService == null)
                {
                    this.MiddlewareService = new MiddlewareService();
                }
                else if (!this.MiddlewareService.GameServer.IsStarted && !this.MiddlewareService.LoginServer.IsStarted)
                {
                    this.MiddlewareService = new MiddlewareService();
                }
            }
            catch (Exception ex)
            {
            }
        }

    }
}
