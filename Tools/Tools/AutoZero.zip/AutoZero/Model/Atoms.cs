﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoZero.Model
{
    public class Atoms
    {
        public byte[] Packet { get; set; }
        public bool IsUse { get; set; }
    }
}
