﻿using AutoAnswer.command;
using AutoAnswer.Services.Interfaces;
using AutoZero.Model;
using SimpleTCP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Threading;

namespace AutoAnswer.Services
{
    public class AtomService : IAtomService
    {
        public bool IsUse { get; set; }
        private readonly SimpleTcpClient _midClient;
        private readonly TcpClient _tcpClient;
        private List<Atoms> Atoms { get; set; } = new List<Atoms>();
        public AtomService(SimpleTcpClient midClient, TcpClient game)
        {
            this._midClient = midClient;
            this._tcpClient = game;
        }
        public void UseAtom()
        {
            try
            {
                foreach (var atom in Atoms)
                {
                    var itemId = atom.Packet.Skip(4).Take(3).ToArray();
                    var packet = PacketContants.ADDINATION;
                    packet[8] = itemId[0];
                    packet[9] = itemId[1];
                    packet[10] = itemId[2];
                    this._midClient.Write(packet);
                    atom.IsUse = true;
                }
                Atoms = Atoms.Where(x => !x.IsUse).ToList();
            }
            catch (Exception ex)
            {

            }
            
        }

        public bool IsBuyAtom(byte[] packet)
        {
            var pkg = packet.vnToString();
            var item = PacketContants.BUY_ATOM.vnToString();
            var result = pkg.StartsWith(item);
            if(result)
            {
                this.Atoms.Add(new AutoZero.Model.Atoms
                {
                    Packet = packet,
                    IsUse = false
                });
            }
            return result;
        }
    }
}
